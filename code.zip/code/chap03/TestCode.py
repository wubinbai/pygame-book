# Test Code

something = 123
print(something)
something = "ABC"
print(something)

A = 123
B = "ABC"
C = 456
D = "DEF"
print(A,B,C,D)

name = "John Carpenter"
birth = "11/11/2011"
print(name,birth)

print("String","Theory", sep='-', end=':')
print()

import sys
print(sys.copyright)

print(sys.platform)

print(sys.version)

import datetime
from datetime import datetime, timezone
print(datetime.now())

