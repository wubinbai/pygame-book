print("Hello Python")

