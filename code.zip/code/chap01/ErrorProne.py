# Funny syntax error example

# Bad function!
def ErrorProne():
    printgobblegobble("Hello there!")
#    print = 10
#    print(print)

print("See, nothing bad happened. You worry too much!")

ErrorProne()

