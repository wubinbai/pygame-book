# Structured program

# Function definition
def PrintName(name):
    print("The name is " + name + ".")

# Start of program
PrintName("Jane Doe")

